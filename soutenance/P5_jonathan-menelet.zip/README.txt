Bonjour,

je vous met ce message pour préciser que le site peut être visité via gitpage car l'api est hebergée sur une 
plateforme certe lente mais gratuite (herokuapp). je voue met le liens ci dessous, pour tester le site ça sera surement plus simple pour vous

GitPage : https://jonathanm98.github.io/jonathanmenelet_5_01112021/